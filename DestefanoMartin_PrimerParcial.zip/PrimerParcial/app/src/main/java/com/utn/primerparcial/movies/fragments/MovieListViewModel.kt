package com.utn.primerparcial.movies.fragments

import androidx.lifecycle.ViewModel

class MovieListViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}