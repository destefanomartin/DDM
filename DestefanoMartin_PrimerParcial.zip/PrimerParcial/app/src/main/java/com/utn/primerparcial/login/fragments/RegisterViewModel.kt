package com.utn.primerparcial.login.fragments

import androidx.lifecycle.ViewModel

class RegisterViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}