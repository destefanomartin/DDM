package com.utn.primerparcial.login

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.utn.primerparcial.R

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
    }
}