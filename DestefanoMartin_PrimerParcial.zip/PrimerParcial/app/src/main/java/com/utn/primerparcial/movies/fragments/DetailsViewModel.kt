package com.utn.primerparcial.movies.fragments

import androidx.lifecycle.ViewModel

class DetailsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}