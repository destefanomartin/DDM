package com.utn.primerparcial.login.fragments

import androidx.lifecycle.ViewModel

class UserProfileViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}