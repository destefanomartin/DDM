package com.utn.primerparcial.movies.fragments

import androidx.lifecycle.ViewModel

class CreateMovieViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}